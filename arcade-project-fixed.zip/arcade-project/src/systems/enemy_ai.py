import arcade

AGGRO_DISTANCE = 260

CHASE_SPEED = 2.6


def update_enemy_ai(game):

    for e in game.enemies:
        left = game.camera.position[0] - game.window.width / 2
        right = game.camera.position[0] + game.window.width / 2

        if e.center_x < left - 200 or e.center_x > right + 200:
            continue

        dist = abs(game.player.center_x - e.center_x)

        if dist < AGGRO_DISTANCE:
            direction = 1 if game.player.center_x > e.center_x else -1
            e.change_x = CHASE_SPEED * direction
            continue

        if hasattr(e, "patrol_left") and hasattr(e, "patrol_right"):
            if e.center_x <= e.patrol_left:
                e.change_x = abs(e.change_x) if e.change_x != 0 else 1.5
            elif e.center_x >= e.patrol_right:
                e.change_x = -abs(e.change_x) if e.change_x != 0 else -1.5
        else:
            e.change_x = 0
