import math
import random
import arcade

from ..constants import GRAVITY, MIN_ENEMY_SPAWN_DIST
from ..entities.elite_enemy import EliteEnemy
from ..entities.fly_enemy import FlyEnemy
from ..sprites import Enemy

TILE_PATH = "assets/images/ground_tile.png"

_cached_tex = None
_cached_scale = None


def _get_tile():
    global _cached_tex, _cached_scale

    if _cached_tex is None:
        _cached_tex = arcade.load_texture(TILE_PATH)
        target_height = 40
        _cached_scale = target_height / _cached_tex.height

    return _cached_tex, _cached_scale


def _create_platform(game, center_x, center_y, width_px):
    tex, scale = _get_tile()

    tile_w = tex.width * scale
    tiles = max(1, math.ceil(width_px / tile_w))
    start_x = center_x - width_px / 2

    first = None
    last = None

    for i in range(tiles):
        t = arcade.Sprite(TILE_PATH, scale=scale)
        t.left = start_x + i * tile_w
        t.center_y = center_y

        game.platforms.append(t)
        game.platform_tiles.append(t)

        if first is None:
            first = t
        last = t

    class Platform:
        pass

    platform = Platform()
    platform.left = first.left
    platform.right = last.right
    platform.top = first.top
    platform.center_x = (platform.left + platform.right) / 2

    return platform


def _attach_patrol(enemy, platform):
    enemy.patrol_left = platform.left + 20
    enemy.patrol_right = platform.right - 20
    enemy.change_x = random.choice([-1.5, 1.5])



def _far_from_player(game, x: float) -> bool:
    p = getattr(game, "player", None)
    if p is None:
        return True
    try:
        px = float(p.center_x)
    except Exception:
        return True
    return abs(x - px) >= MIN_ENEMY_SPAWN_DIST


def generate_segment(game):
    start_x = game.generated_until

    new_y = game.last_platform_y + random.randint(-100, 100)
    new_y = max(80, min(300, new_y))

    gap = random.randint(80, 180)
    width = random.randint(200, 360)

    center_x = start_x + gap + width / 2

    platform = _create_platform(game, center_x, new_y, width)

    coin = arcade.Sprite("assets/images/coin.png", scale=0.35)
    coin.center_x = platform.center_x
    coin.center_y = platform.top + 50
    game.coins.append(coin)

    difficulty = 1.0 + game.distance / 300.0

    enemy_chance = min(0.6 + game.distance / 3000.0, 0.9)

    if random.random() < enemy_chance and _far_from_player(game, platform.center_x):
        e = Enemy(platform.center_x, platform.top + 40)

        _attach_patrol(e, platform)
        e.change_x *= min(difficulty, 3.0)

        game.enemies.append(e)

        e.physics = arcade.PhysicsEnginePlatformer(
            e,
            game.platforms,
            gravity_constant=GRAVITY
        )

    elite_chance = min(0.03 + game.distance / 6000.0, 0.18)

    if random.random() < elite_chance and _far_from_player(game, platform.center_x):
        elite = EliteEnemy(platform.center_x, 0)
        elite.center_y = platform.top + elite.height / 2 + 2

        _attach_patrol(elite, platform)
        elite.change_x *= min(difficulty, 2.5)

        game.elites.append(elite)

        elite.physics = arcade.PhysicsEnginePlatformer(
            elite,
            game.platforms,
            gravity_constant=GRAVITY
        )

    if game.distance > 1000 and random.random() < 0.22:
        fly = FlyEnemy(platform.center_x, platform.top + 180)
        game.fly_enemies.append(fly)

    game.last_platform_y = new_y
    game.generated_until = platform.right
    from ..entities.package import Package

    if game.delivery_state == "spawn_package" and platform.center_x > game.next_delivery_x:
        pkg = Package(platform.center_x, platform.top + 40)
        game.packages.append(pkg)

        game.active_package = pkg
        game.delivery_state = "waiting_pickup"

        game.delivery_target_x = platform.center_x + 400