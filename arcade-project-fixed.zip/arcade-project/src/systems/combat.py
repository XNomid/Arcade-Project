import arcade
import math

from ..entities.bullet import Bullet
from ..constants import SHOOT_COOLDOWN, DAMAGE_COOLDOWN


# ------------------------------------------------
# PLAYER SHOOT
# ------------------------------------------------

def player_shoot(game, dx, dy):

    if game.shoot_timer > 0:
        return

    length = math.hypot(dx, dy)
    if length == 0:
        return

    dx /= length
    dy /= length

    bullet = Bullet(
        game.player.center_x,
        game.player.center_y,
        dx,
        dy,
        speed=12,
        max_range=800
    )

    game.bullets.append(bullet)

    if game.window.sound_enabled:
        arcade.play_sound(game.sounds["shoot"])

    game.shoot_timer = SHOOT_COOLDOWN


# ------------------------------------------------
# ELITE SHOOT
# ------------------------------------------------

def elites_shoot(game, dt):

    for elite in game.elites:

        elite.shoot_timer -= dt
        if elite.shoot_timer > 0:
            continue

        dx = game.player.center_x - elite.center_x
        dy = game.player.center_y - elite.center_y

        dist = math.hypot(dx, dy)
        if dist == 0 or dist > 600:
            continue

        dx /= dist
        dy /= dist

        elite.shoot_timer = elite.cooldown

        bullet = Bullet(
            elite.center_x,
            elite.center_y,
            dx,
            dy,
            speed=7,
            color=arcade.color.RED,
            max_range=650
        )

        game.enemy_bullets.append(bullet)


# ------------------------------------------------
# BULLET UPDATE
# ------------------------------------------------

def update_bullets(game):

    game.bullets.update()
    game.enemy_bullets.update()

    for b in list(game.bullets):

        if arcade.check_for_collision_with_list(b, game.platforms):
            b.remove_from_sprite_lists()
            continue

        hit = []
        hit += arcade.check_for_collision_with_list(b, game.enemies)
        hit += arcade.check_for_collision_with_list(b, game.elites)
        hit += arcade.check_for_collision_with_list(b, game.fly_enemies)

        if hit:
            b.remove_from_sprite_lists()

            for e in hit:
                e.remove_from_sprite_lists()
                game.money += 0
                game.kills += 1

    # --- пули врагов ---
    for b in list(game.enemy_bullets):

        if arcade.check_for_collision_with_list(b, game.platforms):
            b.remove_from_sprite_lists()
            continue

        if arcade.check_for_collision(b, game.player):
            b.remove_from_sprite_lists()
            _damage_player(game)


# ------------------------------------------------
# CONTACT DAMAGE
# ------------------------------------------------

def update_contact_damage(game, dt):

    if game.damage_timer > 0:
        return

    if (
        arcade.check_for_collision_with_list(game.player, game.enemies)
        or arcade.check_for_collision_with_list(game.player, game.elites)
        or arcade.check_for_collision_with_list(game.player, game.fly_enemies)
    ):
        _damage_player(game)


# ------------------------------------------------
# DAMAGE
# ------------------------------------------------

def _damage_player(game):

    if game.damage_timer > 0:
        return

    game.player_hp -= 1
    game.damage_timer = DAMAGE_COOLDOWN

    if game.player_hp <= 0:
        game.player_hp = 0

    if "hit" in game.sounds and game.window.sound_enabled:
        arcade.play_sound(game.sounds["hit"])

