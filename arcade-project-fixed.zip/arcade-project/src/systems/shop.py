import arcade


def toggle_shop(game):
    game.shop_open = not game.shop_open


def handle_shop_key(game, symbol):
    if symbol == arcade.key.KEY_1:
        buy_hp(game)
    elif symbol == arcade.key.KEY_2:
        buy_reload(game)
    elif symbol == arcade.key.KEY_3:
        buy_speed(game)


def buy_hp(game):
    if game.upgrades.get("hp"):
        return
    cost = 20
    if game.money >= cost:
        game.money -= cost
        game.player_hp += 1
        game.upgrades["hp"] = True


def buy_reload(game):
    if game.upgrades.get("reload"):
        return
    cost = 25
    if game.money >= cost:
        game.money -= cost
        game.shoot_cooldown = max(0.45, game.shoot_cooldown * 0.6)
        game.upgrades["reload"] = True


def buy_speed(game):
    if game.upgrades.get("speed"):
        return
    cost = 30
    if game.money >= cost:
        game.money -= cost
        game.move_speed += 2
        game.upgrades["speed"] = True


def draw_shop(game):
    w = 520
    h = 240
    left = (game.window.width - w) // 2
    bottom = (game.window.height - h) // 2
    right = left + w
    top = bottom + h

    arcade.draw_lrbt_rectangle_filled(left, right, bottom, top, (0, 0, 0, 190))
    arcade.draw_lrbt_rectangle_outline(left, right, bottom, top, arcade.color.WHITE, 2)

    y = top - 40
    arcade.draw_text("SHOP (E to close)", left + 20, y, arcade.color.WHITE, 18)
    y -= 40

    def status(key):
        return "BOUGHT" if game.upgrades.get(key) else ""

    arcade.draw_text(f"1) +1 HP  (20💰)   {status('hp')}", left + 20, y, arcade.color.WHITE, 16)
    y -= 35
    arcade.draw_text(f"2) Reload (25💰)   {status('reload')}", left + 20, y, arcade.color.WHITE, 16)
    y -= 35
    arcade.draw_text(f"3) Speed  (30💰)   {status('speed')}", left + 20, y, arcade.color.WHITE, 16)
    y -= 45

    arcade.draw_text(f"Your money: {game.money}💰", left + 20, y, arcade.color.YELLOW, 16)
