import arcade


def update_economy(game):

    game.distance = int(game.player.center_x / 10)

    hit = arcade.check_for_collision_with_list(game.player, game.coins)

    for coin in hit:
        coin.remove_from_sprite_lists()
        game.money += 1
