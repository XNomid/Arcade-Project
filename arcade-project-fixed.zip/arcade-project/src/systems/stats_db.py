import sqlite3
from pathlib import Path

DB_PATH = Path("stats.db")


def _get_connection():
    return sqlite3.connect(DB_PATH)


def init_db():
    print("INIT DB CALLED")

    conn = _get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kills INTEGER NOT NULL,
            distance INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()


def save_record(kills: int, distance: int):
    conn = _get_connection()
    cur = conn.cursor()

    cur.execute(
        "INSERT INTO records (kills, distance) VALUES (?, ?)",
        (kills, distance)
    )

    conn.commit()
    conn.close()


def get_best_records(limit: int = 5):
    conn = _get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT kills, distance
        FROM records
        ORDER BY distance DESC, kills DESC
        LIMIT ?
    """, (limit,))

    rows = cur.fetchall()
    conn.close()
    return rows
