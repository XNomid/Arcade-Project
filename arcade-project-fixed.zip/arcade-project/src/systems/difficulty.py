def difficulty_multiplier(distance):
    return 1 + distance / 200
