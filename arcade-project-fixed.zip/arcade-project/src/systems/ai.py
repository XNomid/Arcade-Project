def update_enemies(game, dt: float):
    for sprite_list in (game.enemies, game.elites):
        for e in sprite_list:
            if not hasattr(e, "patrol_left"):
                continue

            e.center_x += e.change_x

            if e.center_x < e.patrol_left:
                e.center_x = e.patrol_left
                e.change_x = abs(e.change_x)
            elif e.center_x > e.patrol_right:
                e.center_x = e.patrol_right
                e.change_x = -abs(e.change_x)
