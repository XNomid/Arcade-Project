# src/views/game_over_view.py
import arcade

from ..systems import stats_db

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720


class GameOverView(arcade.View):

    def __init__(self, kills, distance):
        super().__init__()

        self.kills = kills
        self.distance = distance

        stats_db.init_db()
        records = stats_db.get_best_records(1)

        if records:
            self.best_kills, self.best_distance = records[0]
        else:
            self.best_kills, self.best_distance = 0, 0

    def on_draw(self):
        self.clear(arcade.color.BLACK)

        arcade.draw_text(
            "YOU DIED",
            SCREEN_WIDTH // 2,
            SCREEN_HEIGHT - 140,
            arcade.color.RED,
            60,
            anchor_x="center"
        )

        arcade.draw_text(
            f"Kills: {self.kills}",
            SCREEN_WIDTH // 2,
            420,
            arcade.color.WHITE,
            26,
            anchor_x="center"
        )

        arcade.draw_text(
            f"Distance: {self.distance}",
            SCREEN_WIDTH // 2,
            380,
            arcade.color.WHITE,
            26,
            anchor_x="center"
        )

        arcade.draw_text(
            f"Best kills: {self.best_kills}",
            SCREEN_WIDTH // 2,
            320,
            arcade.color.YELLOW,
            22,
            anchor_x="center"
        )

        arcade.draw_text(
            f"Best distance: {self.best_distance}",
            SCREEN_WIDTH // 2,
            290,
            arcade.color.YELLOW,
            22,
            anchor_x="center"
        )

        arcade.draw_text(
            "Press ENTER to restart",
            SCREEN_WIDTH // 2,
            180,
            arcade.color.GRAY,
            18,
            anchor_x="center"
        )

    def on_key_press(self, symbol, modifiers):
        if symbol == arcade.key.ENTER:
            from .game_view import GameView
            self.window.show_view(GameView())
