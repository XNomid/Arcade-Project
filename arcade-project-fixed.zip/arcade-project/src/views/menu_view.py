import arcade

from ..constants import SCREEN_WIDTH, SCREEN_HEIGHT


class MenuView(arcade.View):

    def __init__(self):
        super().__init__()

        self.selected_location = 0
        self.locations = ["Forest"]
        self.sound_enabled = True
        self.in_settings = False

        if not hasattr(self.window, "sound_enabled"):
            self.window.sound_enabled = True

    def on_draw(self):
        self.clear(arcade.color.BLACK)

        if not self.in_settings:
            self._draw_main_menu()
        else:
            self._draw_settings()

    def _draw_main_menu(self):

        arcade.draw_text(
            "RUNNER GAME",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT - 120,
            arcade.color.WHITE,
            48,
            anchor_x="center"
        )

        arcade.draw_text(
            "ENTER — PLAY",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 + 40,
            arcade.color.LIGHT_GREEN,
            22,
            anchor_x="center"
        )

        arcade.draw_text(
            f"LOCATION: {self.locations[self.selected_location]} (A/D)",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2,
            arcade.color.YELLOW,
            18,
            anchor_x="center"
        )

        arcade.draw_text(
            "S — SETTINGS",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 - 60,
            arcade.color.WHITE,
            18,
            anchor_x="center"
        )
        arcade.draw_text(
            "Q — QUIT",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 - 120,
            arcade.color.RED,
            18,
            anchor_x="center"
        )

    def _draw_settings(self):

        status = "ON" if self.window.sound_enabled else "OFF"

        arcade.draw_text(
            "SETTINGS",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT - 120,
            arcade.color.WHITE,
            40,
            anchor_x="center"
        )

        arcade.draw_text(
            f"SOUND: {status} (ENTER)",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2,
            arcade.color.YELLOW,
            22,
            anchor_x="center"
        )

        arcade.draw_text(
            "ESC — BACK",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 - 60,
            arcade.color.WHITE,
            18,
            anchor_x="center"
        )

    def on_key_press(self, symbol, modifiers):

        if not self.in_settings:

            if symbol == arcade.key.ENTER:
                from .game_view import GameView
                game = GameView()
                self.window.show_view(game)

                game.location_id = self.selected_location
                self.window.show_view(game)

            elif symbol == arcade.key.A:
                self.selected_location = max(0, self.selected_location - 1)

            elif symbol == arcade.key.D:
                self.selected_location = min(
                    len(self.locations) - 1,
                    self.selected_location + 1
                )

            elif symbol == arcade.key.S:
                self.in_settings = True

            elif symbol == arcade.key.Q:
                arcade.exit()

        else:
            if symbol == arcade.key.ENTER:
                self.window.sound_enabled = not self.window.sound_enabled

            elif symbol == arcade.key.ESCAPE:
                self.in_settings = False
