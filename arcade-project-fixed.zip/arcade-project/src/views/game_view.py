import math

import arcade
from src.constants import GRAVITY, MIN_ENEMY_SPAWN_DIST
from src.systems.enemy_ai import update_enemy_ai

from ..constants import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    MOVE_SPEED,
    PLAYER_JUMP_SPEED,
    SHOOT_COOLDOWN,
    ABYSS_Y,
)
from ..sprites import Player
from ..systems import combat, economy, generator


class GameView(arcade.View):
    def __init__(self):
        super().__init__()
        self.packages = arcade.SpriteList()
        self.delivery_enabled = False

        self.active_package = None
        self.delivery_marker = None  # ← СПРАЙТ, НЕ список

        self.delivery_state = "spawn_package"
        self.next_delivery_x = 800
        self.delivery_target_x = None

        self.player = Player()
        self.player_hp = 3
        self.kills = 0
        self.delivery_markers = arcade.SpriteList()

        self.damage_timer = 0.0
        self.shoot_timer = 0.0
        self.shoot_cooldown = SHOOT_COOLDOWN

        self.money = 0
        self.distance = 0

        self.upgrades = {"hp": False, "damage": False, "reload": False}

        self.platforms = arcade.SpriteList(use_spatial_hash=True)
        self.platform_tiles = arcade.SpriteList()
        self.coins = arcade.SpriteList()
        self.enemies = arcade.SpriteList()
        self.elites = arcade.SpriteList()
        self.fly_enemies = arcade.SpriteList()
        self.bullets = arcade.SpriteList()
        self.enemy_bullets = arcade.SpriteList()

        self.physics = None

        self.left_pressed = False
        self.right_pressed = False
        self.move_speed = MOVE_SPEED

        self.generated_until = 0
        self.last_platform_y = 120

        self.packages = arcade.SpriteList()
        self.active_package = None
        self.delivery_zone = None
        self.delivery_marker = arcade.SpriteList()
        self.delivery_state = "spawn_package"
        self.delivery_pickup_x = 0.0
        self.delivery_target_x = 0.0
        self.next_delivery_x = 800.0

        self.shop_open = False

        self.camera = arcade.Camera2D()
        self.gui_camera = arcade.Camera2D()

        self.bg_color = arcade.color.DARK_SLATE_GRAY

        self.sounds = {"shoot": arcade.load_sound("assets/sounds/coin.wav")}

        self._game_over = False


    def _cull_nearby_enemies(self):
        if not self.player:
            return
        px = self.player.center_x
        def far(s):
            return abs(s.center_x - px) >= MIN_ENEMY_SPAWN_DIST

        for sl in (self.enemies, self.elites, self.fly_enemies):
            for s in list(sl):
                if not far(s):
                    s.remove_from_sprite_lists()

    def on_show_view(self):
        self.platforms = arcade.SpriteList(use_spatial_hash=True)
        self.platform_tiles = arcade.SpriteList()
        self.coins = arcade.SpriteList()
        self.enemies = arcade.SpriteList()
        self.elites = arcade.SpriteList()
        self.fly_enemies = arcade.SpriteList()
        self.bullets = arcade.SpriteList()
        self.enemy_bullets = arcade.SpriteList()

        self.generated_until = 0
        self.last_platform_y = 120

        self.money = 0
        self.distance = 0
        self.kills = 0
        self.player_hp = 3

        self.damage_timer = 0.0
        self.shoot_timer = 0.0

        # --- DELIVERY ---
        self.packages = arcade.SpriteList()
        self.active_package = None
        self.delivery_marker = arcade.SpriteList()

        self.delivery_state = "spawn_package"
        self.delivery_target_x = 0
        self.next_delivery_x = 600

        self._game_over = False

        generator.generate_segment(self)

        first_platform = self.platforms[0]
        self.player.center_x = first_platform.center_x
        self.player.center_y = first_platform.top + self.player.height / 2 + 4

        self._cull_nearby_enemies()


        for _ in range(11):
            generator.generate_segment(self)

        self.physics = arcade.PhysicsEnginePlatformer(
            self.player,
            self.platforms,
            gravity_constant=GRAVITY,
        )

        self._ensure_enemy_physics()
        self._scroll_to_player()

    def on_key_press(self, symbol, modifiers):
        if symbol == arcade.key.ESCAPE:
            from .menu_view import MenuView
            self.window.show_view(MenuView())
            return

        from ..systems import shop

        if symbol == arcade.key.A:
            self.left_pressed = True
        elif symbol == arcade.key.D:
            self.right_pressed = True
        elif symbol == arcade.key.W:
            if self.physics and self.physics.can_jump():
                self.player.change_y = PLAYER_JUMP_SPEED
        elif symbol == arcade.key.E:
            shop.toggle_shop(self)
            self._update_movement()
            return

        if self.shop_open:
            shop.handle_shop_key(self, symbol)
            return

        self._update_movement()

    def on_key_release(self, symbol, modifiers):
        if symbol == arcade.key.A:
            self.left_pressed = False
        elif symbol == arcade.key.D:
            self.right_pressed = False
        self._update_movement()

    def _update_movement(self):
        if self.left_pressed and not self.right_pressed:
            self.player.change_x = -self.move_speed
        elif self.right_pressed and not self.left_pressed:
            self.player.change_x = self.move_speed
        else:
            self.player.change_x = 0

    def on_mouse_press(self, x, y, button, modifiers):
        if self.shop_open:
            return
        if self.shoot_timer > 0:
            return

        wx, wy = self.camera.unproject((x, y))[:2]
        dx = wx - self.player.center_x
        dy = wy - self.player.center_y

        combat.player_shoot(self, dx, dy)
        self.shoot_timer = self.shoot_cooldown

    def on_update(self, dt: float):
        if self._game_over:
            return

        if self.shop_open:
            return

        self.damage_timer = max(0.0, self.damage_timer - dt)
        self.shoot_timer = max(0.0, self.shoot_timer - dt)

        if self.physics:
            self.physics.update()

        self.distance = max(self.distance, int(self.player.center_x))
        # ---------- DELIVERY SYSTEM ----------

        from ..entities.package import Package
        if self.delivery_enabled:
            self._update_delivery()

        if self.delivery_state == "spawn_package":
            spawn_x = self.player.center_x + 200

            pkg = Package(spawn_x, self.player.center_y + 60)
            self.packages.append(pkg)

            self.delivery_target_x = spawn_x + 400

            if self.delivery_marker:
                self.delivery_marker.clear()

            marker = arcade.SpriteSolidColor(40, 120, arcade.color.YELLOW)
            marker.center_x = self.delivery_target_x
            marker.center_y = self.player.center_y + 120

            self.delivery_marker.append(marker)

            self.delivery_marker.center_x = self.delivery_target_x
            self.delivery_marker.center_y = self.player.center_y + 80

            self.delivery_state = "waiting_pickup"

        if self.delivery_state == "waiting_pickup":

            hit = arcade.check_for_collision_with_list(self.player, self.packages)

            if hit:
                self.active_package = hit[0]
                self.active_package.carried = True
                self.delivery_state = "carrying"

        if self.delivery_state == "carrying" and self.active_package:
            self.active_package.center_x = self.player.center_x - 30
            self.active_package.center_y = self.player.center_y + 40

        if self.delivery_state == "carrying":

            if self.player.center_x >= self.delivery_target_x:
                self.money += 0

                self.active_package.remove_from_sprite_lists()
                self.active_package = None

                self.delivery_marker = arcade.SpriteList()

                self.delivery_state = "spawn_package"

        self._ensure_enemy_physics()

        for e in list(self.enemies):
            if getattr(e, "physics", None):
                e.physics.update()
            e.update()

        for elite in list(self.elites):
            if getattr(elite, "physics", None):
                elite.physics.update()
            try:
                elite.update(dt, self)
            except TypeError:
                elite.update()

        for f in list(self.fly_enemies):
            try:
                f.update(dt, self)
            except TypeError:
                f.update()

        update_enemy_ai(self)

        combat.elites_shoot(self, dt)
        combat.update_bullets(self)
        combat.update_contact_damage(self, dt)

        economy.update_economy(self)

        if self.player.center_x + 800 > self.generated_until:
            generator.generate_segment(self)
            if self.physics:
                self.physics = arcade.PhysicsEnginePlatformer(
                    self.player,
                    self.platforms,
                    gravity_constant=GRAVITY,
                )

        self._update_delivery()

        if self.player.center_y < ABYSS_Y or self.player_hp <= 0:
            self._end_game()
            return

        self._scroll_to_player()

    def _platform_top_at(self, x: float):
        best = None
        best_top = None
        for p in self.platforms:
            if p.left <= x <= p.right:
                if best_top is None or p.top > best_top:
                    best = p
                    best_top = p.top
        return best

    def _spawn_delivery(self, pickup_x: float):
        p_pick = self._platform_top_at(pickup_x)
        if not p_pick:
            self.next_delivery_x += 200
            return

        pkg = arcade.SpriteSolidColor(26, 26, arcade.color.ORANGE)
        pkg.center_x = pickup_x
        pkg.center_y = p_pick.top + pkg.height / 2 + 2
        self.packages.append(pkg)

        self.delivery_pickup_x = pickup_x
        self.delivery_target_x = pickup_x + 400

        p_drop = self._platform_top_at(self.delivery_target_x)
        marker_y = (p_drop.top + 60) if p_drop else (p_pick.top + 60)

        if self.delivery_marker:
            self.delivery_marker.clear()
        if self.delivery_zone:
            self.delivery_zone.remove_from_sprite_lists()

        self.delivery_marker.clear()

        marker = arcade.SpriteSolidColor(40, 140, arcade.color.YELLOW)
        marker.center_x = self.delivery_target_x
        marker.center_y = self.player.center_y + 80

        self.delivery_marker.append(marker)

        self.delivery_zone = arcade.SpriteSolidColor(80, 140, (0, 0, 0, 0))
        self.delivery_zone.center_x = self.delivery_target_x
        self.delivery_zone.center_y = marker_y

        self.delivery_state = "waiting_pickup"

    def _update_delivery(self):
        if self.delivery_state == "spawn_package":

            from ..entities.package import Package

            x = self.next_delivery_x
            y = self.player.center_y

            package = Package(x, y)
            self.packages.append(package)

            self.active_package = package

            self.delivery_target_x = x + 400

            self.delivery_marker = arcade.SpriteSolidColor(40, 120, arcade.color.YELLOW)
            self.delivery_marker.center_x = self.delivery_target_x
            self.delivery_marker.center_y = y + 120

            self.delivery_state = "waiting_pickup"

        elif self.delivery_state == "waiting_pickup":

            hit = arcade.check_for_collision_with_list(self.player, self.packages)
            if hit:
                self.delivery_state = "carrying"

        elif self.delivery_state == "carrying":

            #if self.active_package:
                #self.active_package.center_x = self.player.center_x
                #self.active_package.center_y = self.player.center_y + 50
                #self.active_package.change_x = 0
                #self.active_package.change_y = 0

            if self.player.center_x >= self.delivery_target_x:

                print("DELIVERED!")

                self.money += 0

                #if self.active_package:
                    #self.active_package.remove_from_sprite_lists()
                    #self.active_package = None

                self.delivery_marker = None

                self.next_delivery_x = self.player.center_x + 600
                self.delivery_state = "spawn_package"

    def _ensure_enemy_physics(self):
        for e in self.enemies:
            if getattr(e, "physics", None) is None:
                e.physics = arcade.PhysicsEnginePlatformer(
                    e,
                    self.platforms,
                    gravity_constant=GRAVITY,
                )
        for elite in self.elites:
            if getattr(elite, "physics", None) is None:
                elite.physics = arcade.PhysicsEnginePlatformer(
                    elite,
                    self.platforms,
                    gravity_constant=GRAVITY,
                )

    def _end_game(self):
        if self._game_over:
            return
        self._game_over = True

        from ..systems import stats_db
        stats_db.save_record(self.kills, int(self.distance))

        from .game_over_view import GameOverView
        self.window.show_view(GameOverView(self.kills, int(self.distance)))

    def _scroll_to_player(self):
        self.camera.position = (
            self.player.center_x,
            self.player.center_y
        )

    def on_draw(self):
        self.clear(self.bg_color)
        #self.packages.draw()
        if self.delivery_enabled and self.delivery_marker:
            self.delivery_marker.draw()

        self.delivery_markers.draw()
        self.camera.use()
        self.platform_tiles.draw()

        self.coins.draw()
        self.enemies.draw()
        self.elites.draw()
        self.fly_enemies.draw()
        self.bullets.draw()
        self.enemy_bullets.draw()

        arcade.draw_sprite(self.player)

        self.gui_camera.use()

        arcade.draw_text(f"💰 {self.money}", 20, SCREEN_HEIGHT - 40, arcade.color.WHITE, 16)

        arcade.draw_text(
            f"📏 {self.distance}",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT - 40,
            arcade.color.WHITE,
            16,
            anchor_x="center",
        )

        ratio = max(self.shoot_timer / self.shoot_cooldown, 0.0)
        left = SCREEN_WIDTH - 220
        right = left + 200 * ratio
        bottom = SCREEN_HEIGHT - 36
        top = SCREEN_HEIGHT - 24
        if right > left:
            arcade.draw_lrbt_rectangle_filled(left, right, bottom, top, arcade.color.RED)

        if self.shop_open:
            from ..systems import shop
            shop.draw_shop(self)

        arcade.draw_text(
            f"❤️ HP: {self.player_hp}",
            40,
            SCREEN_HEIGHT - 100,
            arcade.color.RED,
            18,
        )
