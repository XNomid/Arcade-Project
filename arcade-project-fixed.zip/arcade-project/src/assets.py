import arcade
from dataclasses import dataclass


@dataclass(frozen=True)
class Sounds:
    coin: arcade.Sound
    hit: arcade.Sound
    win: arcade.Sound
    jump: arcade.Sound
    music: arcade.Sound | None


def load_sounds() -> Sounds:

    coin = arcade.load_sound("assets/sounds/coin.wav")
    hit = arcade.load_sound("assets/sounds/hit.wav")
    win = arcade.load_sound("assets/sounds/win.wav")
    jump = arcade.load_sound("assets/sounds/jump.wav")


    music = None

    return Sounds(
        coin=coin,
        hit=hit,
        win=win,
        jump=jump,
        music=music
    )
