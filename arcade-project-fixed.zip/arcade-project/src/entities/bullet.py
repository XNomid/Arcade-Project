import math

import arcade

BULLET_SIZE = 6


class Bullet(arcade.SpriteSolidColor):
    def __init__(
            self,
            x: float,
            y: float,
            dx: float,
            dy: float,
            speed: float = 10,
            color=arcade.color.YELLOW,
            max_range: float = 700,
    ):
        super().__init__(BULLET_SIZE, BULLET_SIZE, color)

        self.center_x = x
        self.center_y = y

        dist = math.hypot(dx, dy)
        if dist == 0:
            dist = 1

        self.change_x = (dx / dist) * speed
        self.change_y = (dy / dist) * speed

        self._start_x = x
        self._start_y = y
        self._max_range_sq = max_range * max_range

    def update(self, dt: float = 1 / 60):
        self.center_x += self.change_x
        self.center_y += self.change_y

        dx = self.center_x - self._start_x
        dy = self.center_y - self._start_y
        if dx * dx + dy * dy >= self._max_range_sq:
            self.remove_from_sprite_lists()
