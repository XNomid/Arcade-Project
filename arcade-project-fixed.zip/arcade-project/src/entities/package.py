import arcade


class Package(arcade.Sprite):

    def __init__(self, x, y):
        super().__init__("assets/images/package.png", scale=0.2)

        self.center_x = x
        self.center_y = y

        self.carried = False
