import arcade
import random


class EliteEnemy(arcade.SpriteSolidColor):

    def __init__(self, x, y):
        super().__init__(40, 60, arcade.color.CRIMSON)

        self.center_x = x
        self.center_y = y

        self.speed = random.uniform(1.5, 2.5)

        # ---- кулдаун стрельбы ----
        self.cooldown = random.uniform(1.5, 2.5)
        self.shoot_timer = self.cooldown

    def update(self, dt, game):

        dx = game.player.center_x - self.center_x
        dy = game.player.center_y - self.center_y

        dist = (dx * dx + dy * dy) ** 0.5
        if dist == 0:
            return

        dx /= dist
        dy /= dist

        speed = 2.5

        # пробуем двигаться
        old_x = self.center_x
        old_y = self.center_y

        self.center_x += dx * speed
        self.center_y += dy * speed

        # если врезались в платформу → облет
        if arcade.check_for_collision_with_list(self, game.platforms):

            self.center_x = old_x
            self.center_y = old_y

            # попытка обойти вверх/вниз
            self.center_y += speed * 2

            if arcade.check_for_collision_with_list(self, game.platforms):
                self.center_y -= speed * 4
