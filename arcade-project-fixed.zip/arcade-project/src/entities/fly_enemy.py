import arcade
import math


class FlyEnemy(arcade.Sprite):

    def __init__(self, x, y):
        super().__init__("assets/images/fly_enemy.png", scale=0.8)

        self.center_x = x
        self.center_y = y

        self.base_y = y
        self.timer = 0

    def update(self, dt=1/60, game=None):

        self.timer += dt

        self.center_y = self.base_y + math.sin(self.timer * 2) * 25

        if game:
            dx = game.player.center_x - self.center_x

            if abs(dx) < 500:
                self.change_x = 2 if dx > 0 else -2
            else:
                self.change_x = 0

        self.center_x += self.change_x
