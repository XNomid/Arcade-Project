import arcade
from .constants import PLAYER_MOVE_SPEED


class Player(arcade.Sprite):

    def __init__(self):
        super().__init__()

        # текстуры
        self.idle_texture = arcade.load_texture("assets/images/player_idle.png")
        self.walk_textures = [
            arcade.load_texture("assets/images/player_walk1.png"),
            arcade.load_texture("assets/images/player_walk2.png"),
            arcade.load_texture("assets/images/player_walk3.png"),
        ]

        self.texture = self.idle_texture
        self.scale = 0.11

        self._anim_tick = 0
        self._walk_index = 0

    def animate(self, delta_time):

        moving = abs(self.change_x) > 0.1

        if not moving:
            self.texture = self.idle_texture
            return

        self._anim_tick += 1

        if self._anim_tick >= 6:
            self._anim_tick = 0
            self._walk_index = (self._walk_index + 1) % len(self.walk_textures)
            self.texture = self.walk_textures[self._walk_index]


class Enemy(arcade.Sprite):

    def __init__(self, x, y):
        super().__init__("assets/images/enemy.png", scale=0.2)
        self.jump_cooldown = 0
        self.center_x = x
        self.center_y = y
        self.base_speed = 1.5
        self.patrol_left = x - 100
        self.patrol_right = x + 100
        self.change_x = 2
        self.physics = None

    def update(self, delta_time=1/60):
        self.center_x += self.change_x

        if self.center_x < self.patrol_left or self.center_x > self.patrol_right:
            self.change_x *= -1



def apply_player_controls(player, left, right):

    if player is None:
        return

    if left and not right:
        player.change_x = -PLAYER_MOVE_SPEED
    elif right and not left:
        player.change_x = PLAYER_MOVE_SPEED
    else:
        player.change_x = 0
