import json
import os
from dataclasses import dataclass
from typing import Any

from .constants import SCORES_PATH


@dataclass
class ScoreData:
    best_score: int = 0


def load_scores() -> ScoreData:
    if not os.path.exists(SCORES_PATH):
        return ScoreData(best_score=0)
    try:
        with open(SCORES_PATH, "r", encoding="utf-8") as f:
            raw: dict[str, Any] = json.load(f)
        return ScoreData(best_score=int(raw.get("best_score", 0)))
    except (OSError, ValueError, json.JSONDecodeError):
        return ScoreData(best_score=0)


def save_best_score(best_score: int) -> None:
    os.makedirs(os.path.dirname(SCORES_PATH), exist_ok=True)
    payload = {"best_score": int(best_score)}
    with open(SCORES_PATH, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
