from dataclasses import dataclass


@dataclass(frozen=True)
class LevelDefinition:
    name: str
    map_width: int
    platforms: list[tuple[int, int]]
    coins: list[tuple[int, int]]
    enemies: list[tuple[int, int]]
    portal: tuple[int, int]


LEVELS: list[LevelDefinition] = [
    LevelDefinition(
        name="Level 1",
        map_width=2600,
        platforms=[(300, 120), (550, 120), (800, 120), (1100, 250), (1500, 250), (1900, 120), (2300, 120)],
        coins=[(550, 200), (800, 200), (1100, 330), (1500, 330), (1900, 200)],
        enemies=[(1200, 130), (2000, 130)],
        portal=(2450, 170),
    ),
    LevelDefinition(
        name="Level 2",
        map_width=3200,
        platforms=[(300, 120), (650, 200), (1000, 300), (1350, 200), (1700, 120), (2100, 250), (2500, 350), (2900, 200)],
        coins=[(650, 280), (1000, 380), (2100, 330), (2500, 430), (2900, 280)],
        enemies=[(1750, 130), (2200, 260)],
        portal=(3050, 250),
    ),
]
